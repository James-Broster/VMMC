from .model import VMMC_model
